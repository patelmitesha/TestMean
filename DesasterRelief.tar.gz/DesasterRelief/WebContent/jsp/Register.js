RegisterApp = angular.module('RegisterApp', []);
RegisterApp
		.controller(
				'RegisterCtrl',
				[
						'$scope',
						'$http',
						function($scope, $http) {
							/* $scope.loading=true; */
							$scope.insertData = function(data) {

								$scope.EmployeeCode = data.employeeCode;
								// alert(data.employeeName);
								$scope.EmployeeName = data.employeeName;
								$scope.Password = data.password;
								$scope.DateOfBirth = document
										.getElementById("DateOfBirth").value;
								// alert($scope.DateOfBirth);
								$scope.JoinISRODate = document
										.getElementById("ISRODate").value;

								$http
										.get(
												"../api/getNewUserRegister?employeeCode="
														+ $scope.EmployeeCode
														+ "&username="
														+ $scope.EmployeeName
														+ "&password="
														+ $scope.Password
														+ "&DateOfBirth="
														+ $scope.DateOfBirth
														+ "&JoinISRODate="
														+ $scope.JoinISRODate)
										.then(
												function(response) {
													$scope.errorMsg = response.data;
													var message="";
													if ($scope.errorMsg == "User created successfully") {
														message += "<div class='alert alert-success'>"+ $scope.errorMsg+ "</div>";

													} else {
														message += "<div class='alert alert-danger'>"
																+ $scope.errorMsg
																+ "</div>";
													}
													document.getElementById("message").innerHTML = message;
												}, function(response) {
													$scope.msg = response;
												})
							}
						} ]);