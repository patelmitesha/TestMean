package com.DisasterRelief.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.DisasterRelief.Model.NeedSupplyModel;

public class NeedSupplyDAO {
	private String DriverName;
	private String URL;
	private String UserName;
	private String Password;

	private static final Logger logger = Logger.getLogger(NeedSupplyDAO.class);
	
	public NeedSupplyDAO(String DriverName, String URL, String UserName,
			String Password) {
		this.DriverName = DriverName;
		this.URL = URL;
		this.UserName = UserName;
		this.Password = Password;
	}

	public ArrayList<NeedSupplyModel> getNeedSupplyById(int locationId) {
		NeedSupplyModel needSupplyDetail = null;
		ArrayList<NeedSupplyModel> needSupplyDetails=new ArrayList<NeedSupplyModel>();
		CRUD crud = new CRUD(DriverName, URL, UserName, Password);
		ResultSet rsNeedSupplyDetails = crud.fireSelect("SELECT * FROM needsupply where locationid="+locationId);
		try {
			while (rsNeedSupplyDetails.next()) {
				needSupplyDetail=new NeedSupplyModel();
				needSupplyDetail.setCategoryid(rsNeedSupplyDetails.getInt("categoryid"));
				needSupplyDetail.setEnteredOn(rsNeedSupplyDetails.getDate("enteredon"));
				needSupplyDetail.setLocationid(rsNeedSupplyDetails.getInt("locationid"));
				needSupplyDetail.setNeededOrDonated(rsNeedSupplyDetails.getString("neededordonated"));
				needSupplyDetail.setQuantity(rsNeedSupplyDetails.getInt("quantity"));
				needSupplyDetail.setStatus(rsNeedSupplyDetails.getString("status"));
				needSupplyDetail.setUsername(rsNeedSupplyDetails.getString("username"));
				needSupplyDetails.add(needSupplyDetail);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error(e);
			e.printStackTrace();
		}finally{
			try {
				if(rsNeedSupplyDetails!=null){
					rsNeedSupplyDetails.close();
					rsNeedSupplyDetails=null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error(e);
				e.printStackTrace();
				rsNeedSupplyDetails=null;
			}
		}
		
		return needSupplyDetails;
	}
	
	public boolean addNeedSupply(NeedSupplyModel needsupply) {

		CRUD crud = new CRUD(DriverName, URL, UserName, Password);
		int updateCount = crud.fireInsertUpdate("insert into needsupply (locationid,status,categoryid,quantity,neededordonated,username,enteredon) values ("+needsupply.getLocationid()+",'"+needsupply.getStatus()+"',"+needsupply.getCategoryid()+","+needsupply.getQuantity()+",'"+needsupply.getNeededOrDonated()+"','"+needsupply.getUsername()+"','"+needsupply.getEnteredOn()+"')");
		if (updateCount > 0)
			return true;
		else
			return false;
	}

}
