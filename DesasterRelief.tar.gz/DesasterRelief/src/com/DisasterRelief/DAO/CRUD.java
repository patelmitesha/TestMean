package com.DisasterRelief.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mysql.jdbc.CallableStatement;

public class CRUD {
	public Connection connection;

	private String DriverName; 
	private String URL; 
	private String UserName;
	private String Password;
	
	public CRUD(String DriverName, String URL, String UserName,String Password){
		this.DriverName=DriverName;
		this.URL=URL;
		this.UserName=UserName;
		this.Password=Password;
	}
	public void connect() throws SQLException, InstantiationException,
			IllegalAccessException, ClassNotFoundException {
		Class.forName(DriverName).newInstance();
		connection = DriverManager.getConnection(URL, UserName, Password);

	}

	public void disconnect() {
		if (connection != null) {
			try {
				if (!connection.isClosed()) {
					connection.close();
					connection = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				connection = null;
			}
		}
	}

	public ResultSet fireSelect(String stmt) {
			ResultSet rs=null;
			try{
			connect();
			rs=this.connection.prepareStatement(stmt).executeQuery();
			}catch(Exception ex){
				ex.printStackTrace();
			}
			return rs; 
	}
	
	public int fireInsertUpdate(String sql) {
		int pstmtsql=0;
		try{
			connect();
			PreparedStatement stmt = this.connection.prepareStatement(sql);
			pstmtsql=stmt.executeUpdate();
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			disconnect();
		}
		
		return pstmtsql; 
	}		
}
