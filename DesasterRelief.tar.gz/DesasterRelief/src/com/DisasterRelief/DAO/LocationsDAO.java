package com.DisasterRelief.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.DisasterRelief.Model.LocationsModel;

public class LocationsDAO {
	private String DriverName;
	private String URL;
	private String UserName;
	private String Password;

	private static final Logger logger = Logger.getLogger(LocationsDAO.class);

	public LocationsDAO(String DriverName, String URL, String UserName, String Password) {
		this.DriverName = DriverName;
		this.URL = URL;
		this.UserName = UserName;
		this.Password = Password;
	}

	public LocationsModel getLocationById(int locationId) {
		LocationsModel locationDetail = null;
		CRUD crud = new CRUD(DriverName, URL, UserName, Password);
		ResultSet rsLocationDetails = crud.fireSelect("SELECT * FROM locations where locationid=" + locationId);
		try {
			while (rsLocationDetails.next()) {
				locationDetail = new LocationsModel();
				locationDetail.setArea(rsLocationDetails.getString("area"));
				locationDetail.setLatitude(rsLocationDetails.getString("latitude"));
				locationDetail.setLongitude(rsLocationDetails.getString("longitude"));
				locationDetail.setLocationname(rsLocationDetails.getString("locationname"));
				locationDetail.setLocationid(rsLocationDetails.getInt("locationid"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error(e);
			e.printStackTrace();
			rsLocationDetails = null;
		} finally {
			try {
				if (rsLocationDetails != null) {
						rsLocationDetails.close();
						rsLocationDetails = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error(e);
				e.printStackTrace();
				rsLocationDetails = null;
			}
		}

		return locationDetail;
	}

	public ArrayList<LocationsModel> getAllLocations() {
		LocationsModel locationDetail = null;
		ArrayList<LocationsModel> locationDetails = new ArrayList<LocationsModel>();
		CRUD crud = new CRUD(DriverName, URL, UserName, Password);
		ResultSet rsLocationDetails = crud.fireSelect("SELECT * FROM locations");
		try {
			while (rsLocationDetails.next()) {
				locationDetail = new LocationsModel();
				locationDetail.setArea(rsLocationDetails.getString("area"));
				locationDetail.setLatitude(rsLocationDetails.getString("latitude"));
				locationDetail.setLongitude(rsLocationDetails.getString("longitude"));
				locationDetail.setLocationname(rsLocationDetails.getString("locationname"));
				locationDetail.setLocationid(rsLocationDetails.getInt("locationid"));
				locationDetails.add(locationDetail);
			}
		} catch (SQLException e) {
			logger.error(e);
			e.printStackTrace();
		} finally {
			try {
				if (rsLocationDetails != null) {
						rsLocationDetails.close();
						rsLocationDetails = null;
				}
			} catch (SQLException e) {
				logger.error(e);
				e.printStackTrace();
				rsLocationDetails = null;
			}
		}

		return locationDetails;
	}

	public boolean addLocation(LocationsModel location) {

		CRUD crud = new CRUD(DriverName, URL, UserName, Password);
		int updateCount = crud
				.fireInsertUpdate("insert into locations (locationname, area, latitude, longitude) values ("
						+ location.getLocationname() + ",'" + location.getArea() + "','" + location.getLatitude()
						+ "','" + location.getLongitude() + "')");
		if (updateCount > 0)
			return true;
		else
			return false;
	}

}
