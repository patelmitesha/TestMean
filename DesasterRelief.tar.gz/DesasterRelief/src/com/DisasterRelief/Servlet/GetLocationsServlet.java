package com.DisasterRelief.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.DisasterRelief.DAO.LocationsDAO;
import com.DisasterRelief.Model.LocationsModel;
import com.google.gson.Gson;

/**
 * Servlet implementation class GetAssetDetailServlet
 */
@WebServlet("/api/GetLocationsServlet")
public class GetLocationsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    private static final Logger logger = Logger.getLogger(GetLocationsServlet.class);
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ArrayList<LocationsModel> locations=new ArrayList<LocationsModel>();
		String employeeCode=null;
		try {
			
				String[] DbParams = request.getSession().getServletContext().getInitParameter("DBParam").trim().split(",");
				
				LocationsDAO locationsDao=new LocationsDAO(DbParams[0].trim(),DbParams[1].trim(),DbParams[2].trim(),DbParams[3].trim());
				locations=locationsDao.getAllLocations();
			
		
			
		} catch (Exception ex) {
			logger.error(ex.getStackTrace());
			ex.printStackTrace();
		} 
		String markers="[";
		for (int i=0;i<locations.size();i++) {
			markers+="{"
					+ "coords:{lat:"+locations.get(i).getLatitude() +",lng:"+locations.get(i).getLongitude()+"},"
					+ "icon : 'http://maps.google.com/mapfiles/kml/pal3/icon42.png',"
					+ "content : '<h2>"+locations.get(i).getArea()+"</h2>'"
					+ "}";
			if(i<(locations.size()-1)){
				markers+=",";	
			}
		}
		markers+="]";
		logger.info(markers);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.print(markers);
		out.flush();
		out.close();
	}

}


/*
 * 
 * 
 * var markers=[{
				coords:{lat: 23.0225, lng: 72.5714},
				icon : 'http://maps.google.com/mapfiles/kml/pal3/icon42.png',
				content : '<h2>Ahmedabad</h2>'
			},
			{
				coords:{lat: 23.5880, lng: 72.3693},
				icon : 'http://maps.google.com/mapfiles/kml/pal4/icon40.png',
				content : '<h2>Mehsana</h2>'
			},
			{
				coords:{lat: 23.2156, lng: 72.6369},
//				label : 'GND',
				icon : 'http://maps.google.com/mapfiles/kml/pal4/icon40.png',
				content : '<div id="content">'+
      '<div id="siteNotice">'+
      '</div>'+
      '<h1 id="firstHeading" class="firstHeading">Uluru</h1>'+
      '<div id="bodyContent">'+
      '<p><b>Uluru</b>, also referred to as <b>Ayers Rock</b>, is a large ' +
      'sandstone rock formation in the southern part of the '+
      'Northern Territory, central Australia. It lies 335&#160;km (208&#160;mi) '+
      'south west of the nearest large town, Alice Springs; 450&#160;km '+
      '(280&#160;mi) by road. Kata Tjuta and Uluru are the two major '+
      'features of the Uluru - Kata Tjuta National Park. Uluru is '+
      'sacred to the Pitjantjatjara and Yankunytjatjara, the '+
      'Aboriginal people of the area. It has many springs, waterholes, '+
      'rock caves and ancient paintings. Uluru is listed as a World '+
      'Heritage Site.</p>'+
      '<p>Attribution: Uluru, <a href="https://en.wikipedia.org/w/index.php?title=Uluru&oldid=297882194">'+
      'https://en.wikipedia.org/w/index.php?title=Uluru</a> '+
      '(last visited June 22, 2009).</p>'+
      '</div>'+
      '</div>'
			}
			];
			
			*/
