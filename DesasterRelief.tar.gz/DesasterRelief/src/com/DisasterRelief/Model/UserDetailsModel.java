package com.DisasterRelief.Model;

import java.util.ArrayList;
import java.util.Date;

public class UserDetailsModel {
	private String Username;
	private String Password;
	private Date LastLogin;
	private String Status;
	private ArrayList<String> Roles;
	
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public Date getLastLogin() {
		return LastLogin;
	}
	public void setLastLogin(Date lastLogin) {
		LastLogin = lastLogin;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public ArrayList<String> getRoles() {
		return Roles;
	}
	public void setRoles(ArrayList<String> roles) {
		Roles = roles;
	}

	
}
