package com.DisasterRelief.Model;

import java.util.Date;

public class NeedSupplyModel {
	private int needsupplyid;
	private int locationid;
	private String status;
	private int categoryid;
	private int quantity;
	private String neededOrDonated;
	private String username;
	private Date EnteredOn;
	
	
	
	public int getNeedsupplyid() {
		return needsupplyid;
	}
	public void setNeedsupplyid(int needsupplyid) {
		this.needsupplyid = needsupplyid;
	}
	public int getLocationid() {
		return locationid;
	}
	public void setLocationid(int locationid) {
		this.locationid = locationid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getCategoryid() {
		return categoryid;
	}
	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getNeededOrDonated() {
		return neededOrDonated;
	}
	public void setNeededOrDonated(String neededOrDonated) {
		this.neededOrDonated = neededOrDonated;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Date getEnteredOn() {
		return EnteredOn;
	}
	public void setEnteredOn(Date enteredOn) {
		EnteredOn = enteredOn;
	}
	
	
	
}
